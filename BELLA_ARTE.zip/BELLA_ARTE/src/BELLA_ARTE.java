
import CLASSES.GraficoBarra;
import CLASSES.Txt;
import TELAS.TELA_INICIA;


public class BELLA_ARTE {
    public static void main(String[] args) {
        
        new TELA_INICIA().setVisible(true);
        
       //new GraficoBarra();
        
        Txt txtInicio = new Txt();  
        
        txtInicio.criarPasta("c:/temp");
        txtInicio.criarPasta("c:/backup_daniel");
        txtInicio.criarArquivoTXT("c:/temp/ALUNO.txt");
        txtInicio.criarArquivoTXT("c:/temp/temp.txt");
        txtInicio.criarArquivoTXT("c:/temp/MENSALIDADE.txt");
        txtInicio.criarArquivoTXT("c:/temp/ITEM.txt");
        txtInicio.criarArquivoTXT("c:/temp/LIVRO.txt");
        txtInicio.backup("c:/temp","c:/backup_daniel/temp_");  //IMCOMPLETO

    }
    
}
