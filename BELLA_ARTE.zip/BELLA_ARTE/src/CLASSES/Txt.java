package CLASSES;
/*
import TELAS.TESTE;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Vector;
import javax.swing.JFrame;
*/
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.channels.FileChannel;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Txt{
    private JTextField TextField1;
    private JTextField TextField2;
    private JTextField TextField3;
    private JTextField TextField4;
    private JTextField TextField5;
    private JTable Table1;
    public String ultimo_registro;
    public String novo_registro;
    public String arquivo_temp;
    public int int_variavel;
    public String mes_ano;
    public String dia_mes_ano;
    public String mes;
    public String dia;
    public String ano;
    public String existe_arquivo;
    public String caminho_foto;
    public String valorColuna;
    public String campoString;
    public int qtdEstoque;
    public String stringxxx;
    public int intxxx;
    public int PENDENTE;
    public int PAGO;
    public float PENDENTE_soma;
    public float PAGO_soma;
    public float VEMDA_soma;
    public float DESPESA_soma;
    public float ATIVO_soma;
    public float INATIVO_soma;
    public float floatxxx;
    public String Bigdecimal;
    
    
    public Txt(){   
       arquivo_temp = "c:/temp/temp.txt"; 
    }
     
    public void levar_valores_nos_TextField(String xx1,String xx2,String xx3,String xx4,String xx5){
        TextField1.setText(xx1);
        TextField2.setText(xx2);
        TextField3.setText(xx3);
        TextField4.setText(xx4);
        TextField5.setText(xx5);
    }
     
    public void carregar_valores_jTable(JTable jTable1){
        this.Table1 = jTable1;
        DefaultTableModel model = (DefaultTableModel) this.Table1.getModel();
        this.levar_valores_nos_TextField(
                model.getValueAt(jTable1.getSelectedRow(), 0).toString(),
                model.getValueAt(jTable1.getSelectedRow(), 1).toString(),
                model.getValueAt(jTable1.getSelectedRow(), 2).toString(),
                model.getValueAt(jTable1.getSelectedRow(), 3).toString(),
                model.getValueAt(jTable1.getSelectedRow(), 4).toString());
        
    }
    
    public void ultimo_registro(String filepath, String delimiter){
        try{  
            String currentLine;
            String data[];
            this.ultimo_registro = "0";
            FileReader fr = new FileReader(filepath);
            BufferedReader br = new BufferedReader(fr);
            
            while((currentLine = br.readLine()) != null){
                data = currentLine.split(delimiter);
                this.ultimo_registro = data[0]; 
            }
            this.int_variavel = Integer.parseInt(this.ultimo_registro);
            this.int_variavel++;
            this.novo_registro = Integer.toString(this.int_variavel);
            br.close();
            fr.close();

        }catch(Exception e){
        }
    }
    
    public void grava_ultima_linha(String filepath, String xx, String x1, String x2, String x3, String x4, String x5, String x6, String x7, String x8, String x9, String x10, String x11, String x12, String x13, String x14, String x15, String x16, String x17, String x18, String x19, String x20, String x21, String x22, String x23, String x24, String x25, String x26, String x27, String x28, String x29){     
        try{         
            FileWriter fw = new FileWriter(filepath,true); // true = GRAVA NA ULTIMA LINHA
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            String xxx = x1+xx+x2+xx+x3+xx+x4+xx+x5+xx+x6+xx+x7+xx+x8+xx+x9+xx+x10+xx+x11+xx+x12+xx+x13+xx+x14+xx+x15+xx+x16+xx+x17+xx+x18+xx+x19+xx+x20+xx+x21+xx+x22+xx+x23+xx+x24+xx+x25+xx+x26+xx+x27+xx+x28+xx+x29+xx;
            pw.println(xxx); 
            
            pw.flush();
            pw.close();
            bw.close();
            fw.close();
            
          }catch(Exception e){
          }
    }
    
    public void atulizar_linha_txt(String filepath, String removeTerm, int positionOfTerm, String xx, String x1, String x2, String x3, String x4, String x5, String x6, String x7, String x8, String x9, String x10, String x11, String x12, String x13, String x14, String x15, String x16, String x17, String x18, String x19, String x20, String x21, String x22, String x23, String x24, String x25, String x26, String x27, String x28, String x29){
        int position =  positionOfTerm - 1;
        File oldFile = new File(filepath);
        File newFile = new File(this.arquivo_temp);
       
        String currentLine;
        String data[];
        try{         
            FileWriter fw = new FileWriter(newFile,true); // true = GRAVA NA ULTIMA LINHA
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            
            FileReader fr = new FileReader(filepath);
            BufferedReader br = new BufferedReader(fr);
            while((currentLine = br.readLine()) != null){
                data = currentLine.split(xx);
                //System.out.println(currentLine); LINHA
                //System.out.println(data[1]);     POSIÇAO 2
                if ((data[position].equals(removeTerm)))  {
                    String xxx = x1+xx+x2+xx+x3+xx+x4+xx+x5+xx+x6+xx+x7+xx+x8+xx+x9+xx+x10+xx+x11+xx+x12+xx+x13+xx+x14+xx+x15+xx+x16+xx+x17+xx+x18+xx+x19+xx+x20+xx+x21+xx+x22+xx+x23+xx+x24+xx+x25+xx+x26+xx+x27+xx+x28+xx+x29;
                    System.out.println(xxx);
                    pw.println(xxx);            //ALIMENTA O TXT TEMP
                }else{
                    pw.println(currentLine);    //ALIMENTA O TXT TEMP
                } 
            }
                    pw.flush();
                    pw.close();
                    fr.close();
                    br.close();
                    bw.close();
                    fw.close();
                
                    oldFile.delete();                               //DELETAR TXT ALUNO
                    File renomear_temp_aluno = new File(filepath);  //INSTACIA UMA VARIAVEL COM O NOME DE ARQUIVO  
                    newFile.renameTo(renomear_temp_aluno);          //RENOMEAR TXT TEMP PARA ALUNO
                    newFile.createNewFile();                        //CRIAR UM NOVO TXT TEMP
        }catch(Exception e){
        }
    }
    
    public void criarArquivoTXT(String caminhoArquivo){
        if(!new File(caminhoArquivo).exists()) {
            try{  
            File newFile = new File(caminhoArquivo);
            newFile.createNewFile();
            }catch(Exception e){
            }
        }
    }
    
    public void deletarArquivoTXT(String caminhoArquivo){
        try{  
        File newFile = new File(caminhoArquivo);
        newFile.delete();
        }catch(Exception e){
        }
    }
    public void copiarArquivoTXT(String caminhoArquivoNovo,String caminhoArquivoCopiado){
        criarArquivoTXT(caminhoArquivoNovo);
        File newFile = new File(caminhoArquivoNovo);
        String currentLine;
        String data[];
        try{         
            FileWriter fw = new FileWriter(newFile,false); // true = GRAVA NA ULTIMA LINHA
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            
            FileReader fr = new FileReader(caminhoArquivoCopiado);
            BufferedReader br = new BufferedReader(fr);
            while((currentLine = br.readLine()) != null){
                    pw.println(currentLine);
            }
                    pw.flush();
                    pw.close();
                    fr.close();
                    br.close();
                    bw.close();
                    fw.close();
        }catch(Exception e){
        }
    }
    
     public void criarPasta(String caminhoArquivo){
        File diretorio = new File(caminhoArquivo); 
        if (!diretorio.exists()) { 
            diretorio.mkdirs(); // mkdirs() cria diretórios e subdiretórios. ,
        }
     }
     public void String_Int(String xValor){
        this.intxxx = Integer.parseInt(xValor);
        //System.out.println(this.intxxx);
     }
     public void Int_String(int xValor){
        this.stringxxx = Integer.toString(xValor);
        //System.out.println(this.stringxxx);
     }
     public void String_Float(String xValor){
        this.floatxxx = Float.parseFloat(xValor.replace(".","").replace(",","."));
        //System.out.println(this.floatxxx);
     }
     public void Float_String(float xValor){
        this.stringxxx = Float.toString(xValor); 
        //System.out.println(this.stringxxx);
     }
      public void somar_BigDecimal(String xValor1,String xValor2){
             BigDecimal big1 = new BigDecimal(xValor1.replace(",","."));
             BigDecimal big2 = new BigDecimal(xValor2.replace(",","."));
             BigDecimal bigResult = big1.add(big2);
             this.Bigdecimal = bigResult.setScale(2, RoundingMode.HALF_EVEN).toString().replace(".",",");
      }
      public void subtrair_BigDecimal(String xValor1,String xValor2){
             BigDecimal big1 = new BigDecimal(xValor1.replace(",","."));
             BigDecimal big2 = new BigDecimal(xValor2.replace(",","."));
             BigDecimal bigResult = big1.subtract(big2);
             this.Bigdecimal = bigResult.setScale(2, RoundingMode.HALF_EVEN).toString().replace(".",",");
      }
      public void divide_BigDecimal(String xValor1,String xValor2){
             BigDecimal big1 = new BigDecimal(xValor1.replace(",","."));
             BigDecimal big2 = new BigDecimal(xValor2.replace(",","."));
             BigDecimal bigResult = big1.divide(big2);
             this.Bigdecimal = bigResult.setScale(2, RoundingMode.HALF_EVEN).toString().replace(".",",");
      }
      public void multiply_BigDecimal(String xValor1,String xValor2){
             BigDecimal big1 = new BigDecimal(xValor1.replace(",","."));
             BigDecimal big2 = new BigDecimal(xValor2.replace(",","."));
             BigDecimal bigResult = big1.multiply(big2);
             this.Bigdecimal = bigResult.setScale(2, RoundingMode.HALF_EVEN).toString().replace(".",",");
      }

      public void data(){
            DateTimeFormatter MES_ANO = DateTimeFormatter.ofPattern("MM/yyyy");           
            this.mes_ano = MES_ANO.format(LocalDateTime.now());
            DateTimeFormatter DIA_MES_ANO = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
            this.dia_mes_ano = DIA_MES_ANO.format(LocalDateTime.now());
            DateTimeFormatter MES = DateTimeFormatter.ofPattern("MM"); 
            this.mes = MES.format(LocalDateTime.now());
            DateTimeFormatter DIA = DateTimeFormatter.ofPattern("dd"); 
            this.dia = DIA.format(LocalDateTime.now());
            DateTimeFormatter ANO = DateTimeFormatter.ofPattern("yyyy"); 
            this.ano = ANO.format(LocalDateTime.now());
    }


    public void removeRecord(String filepath, String removeTerm, int positionOfTerm, String delimiter){
        int position =  positionOfTerm;
        File oldFile = new File(filepath);
        File newFile = new File(this.arquivo_temp);
       
        String currentLine;
        String data[];
        try{         
            FileWriter fw = new FileWriter(newFile,true); // true = GRAVA NA ULTIMA LINHA
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            
            FileReader fr = new FileReader(filepath);
            BufferedReader br = new BufferedReader(fr);

            while((currentLine = br.readLine()) != null){
                data = currentLine.split(delimiter);
                //System.out.println(currentLine); LINHA
                //System.out.println(data[1]);     POSIÇAO 2
                if (!(data[position].equalsIgnoreCase(removeTerm)))  {
                    pw.println(currentLine);                        //ALIMENTA O TXT TEMP
                } 
            }
                    pw.flush();
                    pw.close();
                    fr.close();
                    br.close();
                    bw.close();
                    fw.close();
                  
                    oldFile.delete();                               //DELETAR TXT ALUNO
                    File renomear_temp_aluno = new File(filepath);  //INSTACIA UMA VARIAVEL COM O NOME DE ARQUIVO  
                    newFile.renameTo(renomear_temp_aluno);          //RENOMEAR TXT TEMP PARA ALUNO
                    newFile.createNewFile();                        //CRIAR UM NOVO TXT TEMP
                    
        }catch(Exception e){
            System.out.println("erro classe txt(removeRecord)");
        }       
    }   

 public void buscarCampoPeloID(String filepath, String xxx, int colunaCompara, int colunaResultado, String demiliter) {        
        String currentLine;
        String data[];
        this.valorColuna = "";
        try{         
            FileReader fr = new FileReader(filepath);
            BufferedReader br = new BufferedReader(fr);
            while((currentLine = br.readLine()) != null){
                data = currentLine.split(demiliter);
                if ((data[colunaCompara].equals(xxx)))  {
                    this.valorColuna = data[colunaResultado];
                }
            }
                    fr.close();
                    br.close();
        }catch(Exception e){
        }
 }   
    public void registroJaFoiGravado(String caminhoARQUIVO1,String demilitador1, int xx1, String yy1, int xx2, String yy2, int xx3, String yy3){
                    try{  
            this.existe_arquivo = "NAO";
            String currentLineARQUIVO1;
            String dataARQUIVO1[];           
            FileReader frARQUIVO1 = new FileReader(caminhoARQUIVO1);
            BufferedReader brARQUIVO1 = new BufferedReader(frARQUIVO1);          

            while((currentLineARQUIVO1 = brARQUIVO1.readLine()) != null){
                dataARQUIVO1 = currentLineARQUIVO1.split(demilitador1);                 
                        if (dataARQUIVO1[xx1].equals(yy1)&&dataARQUIVO1[xx2].equals(yy2)&&dataARQUIVO1[xx3].equals(yy3)){
                            System.out.println("----REGISTRO REPETIDO---");
                            System.out.println(dataARQUIVO1[xx1] + " = "+ yy1);
                            System.out.println(dataARQUIVO1[xx2] + " = "+ yy2);
                            System.out.println(dataARQUIVO1[xx3] + " = "+ yy3);
                            System.out.println("------------------------");
                            this.existe_arquivo = "SIM";
                        }
            }
            brARQUIVO1.close();
            frARQUIVO1.close();
            }catch(Exception e){
            }  
        
    }    
    
    public void contaRegistroMENSALIDADE(String mesEano,String camihoDoTXT){       
            String currentLine;
            String data[];
            try{
                FileReader fr = new FileReader(camihoDoTXT);
                BufferedReader br = new BufferedReader(fr);
                this.PENDENTE = 0; 
                this.PAGO = 0; 
                this.PENDENTE_soma = 0; 
                this.PAGO_soma = 0; 
                 
                while((currentLine = br.readLine()) != null){
                data = currentLine.split("@#@");
                   if (data[5].equals("PENDENTE")&&data[3].substring(3,10).equals(mesEano)){
                        this.PENDENTE++;
                        String_Float(data[4]);
                        this.PENDENTE_soma=this.PENDENTE_soma + this.floatxxx ;
                    }
                    //System.out.println(this.floatxxx);
                    if (data[5].equals("PAGO")&&data[3].substring(3,10).equals(mesEano)){
                        this.PAGO++;
                        String_Float(data[4]);
                        this.PAGO_soma=this.PAGO_soma +  this.floatxxx  ;
                    }
                }
                fr.close();
                br.close();
            }catch(Exception e){
            }
     }
        public void contaRegistroLIVRO(String mesEano,String camihoDoTXT){       
            String currentLine;
            String data[];
            try{
                FileReader fr = new FileReader(camihoDoTXT);
                BufferedReader br = new BufferedReader(fr);

                this.VEMDA_soma = 0;
                this.DESPESA_soma = 0;
                
                while((currentLine = br.readLine()) != null){
                data = currentLine.split("@#@");
                    if (data[5].equals("SAIDA")&&data[7].substring(3,10).equals(mesEano)){
                        String_Float(data[4]);
                        //System.out.println(this.floatxxx+" DATA "+mesEano+" LIHA "+data[0]);
                        this.VEMDA_soma=this.VEMDA_soma +  this.floatxxx  ;
                    }
                    if (data[5].equals("DESPESA")&&data[7].substring(3,10).equals(mesEano)){
                        String_Float(data[4]);
                        this.DESPESA_soma=this.DESPESA_soma +  this.floatxxx  ;
                    }
                }
                fr.close();
                br.close();
            }catch(Exception e){
            }
     }
    public void contaRegistroALUNO(String mesEano,String camihoDoTXT){       
            String currentLine;
            String data[];
            try{
                FileReader fr = new FileReader(camihoDoTXT);
                BufferedReader br = new BufferedReader(fr);
                this.INATIVO_soma = 0;
                this.ATIVO_soma = 0;
                
                while((currentLine = br.readLine()) != null){
                data = currentLine.split("@#@");
                    if (data[22].equals("")){              
                    }else{
                    if (data[22].substring(3,10).equals(mesEano)){
                        this.INATIVO_soma = this.INATIVO_soma+ 1  ;
                    }}
                    
                    if (data[21].equals("")){              
                    }else{
                    if (data[21].substring(3,10).equals(mesEano)){
                        this.ATIVO_soma = this.ATIVO_soma+ 1  ;
                    }}
                }
                fr.close();
                br.close();
            }catch(Exception e){
            }
     }
    
     public void carregarFoto(String filepath,String delimiter,String xx_id_aluno ){
            try{  
            this.caminho_foto ="";
            String currentLine;
            String data[];

            FileReader fr = new FileReader(filepath);
            BufferedReader br = new BufferedReader(fr);
            
            while((currentLine = br.readLine()) != null){
                data = currentLine.split(delimiter);
                if(data[0].equals(xx_id_aluno)){
                this.caminho_foto = data[20];
            }
            }

            br.close();
            fr.close();

        }catch(Exception e){
        }
     }
     
    public void retornaCampoString(String filepath, String delimitador,String idIcolunaCompara,int colunaRetorna,int colunaCompara){       
            String currentLine;
            String data[];
            try{
                FileReader fr = new FileReader(filepath);
                BufferedReader br = new BufferedReader(fr);
                this.campoString = ""; 
                while((currentLine = br.readLine()) != null){
                data = currentLine.split(delimitador);
                    if (data[colunaCompara].equals(idIcolunaCompara)){
                        this.campoString = data[colunaRetorna];
                    }
                }
                fr.close();
                br.close();
            }catch(Exception e){
            }
     }
     
     
        public void atulizar_valor_txt(String filepath, String removeTerm, int positionOfTerm, String xx, String valor){
        int position =  positionOfTerm - 1;
        File oldFile = new File(filepath);
        File newFile = new File(this.arquivo_temp);
       
        String currentLine;
        String data[];
        try{         
            FileWriter fw = new FileWriter(newFile,true); // true = GRAVA NA ULTIMA LINHA
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            
            FileReader fr = new FileReader(filepath);
            BufferedReader br = new BufferedReader(fr);
            while((currentLine = br.readLine()) != null){
                data = currentLine.split(xx);
                //System.out.println(currentLine); LINHA
                //System.out.println(data[1]);     POSIÇAO 2
                if ((data[position].equals(removeTerm)))  {
                    String xxx = data[0]+xx+data[1]+xx+valor+xx+data[3]+xx+data[4]+xx+data[5]+xx+data[6]+xx+data[7]+xx+data[8]+xx+data[9]+xx+data[10]+xx+data[11]+xx+data[12]+xx+data[13]+xx+data[14]+xx+data[15]+xx+data[16]+xx+data[17]+xx+data[18]+xx+data[19]+xx+data[20]+xx+data[21]+xx+data[22]+xx+data[23]+xx+data[24]+xx+data[25]+xx+data[26]+xx+data[27]+xx+data[28];
                    System.out.println(xxx);
                    pw.println(xxx);            //ALIMENTA O TXT TEMP
                }else{
                    pw.println(currentLine);    //ALIMENTA O TXT TEMP
                } 
            }
                    pw.flush();
                    pw.close();
                    fr.close();
                    br.close();
                    bw.close();
                    fw.close();
                
                    oldFile.delete();                               //DELETAR TXT ALUNO
                    File renomear_temp_aluno = new File(filepath);  //INSTACIA UMA VARIAVEL COM O NOME DE ARQUIVO  
                    newFile.renameTo(renomear_temp_aluno);          //RENOMEAR TXT TEMP PARA ALUNO
                    newFile.createNewFile();                        //CRIAR UM NOVO TXT TEMP
        }catch(Exception e){
        }
    }
        
        public void atualizarEstoque(){
        String currentLineITEM;
        String dataITEM[];
        String currentLineLIVRO;
        String dataLIVRO[];
        ////******CRIAR ARQUIVO "c:/temp/ITEM2.txt" COPIA DO "c:/temp/ITEM.txt"
 
        ////******CRIAR ARQUIVO "c:/temp/ITEM2.txt" COPIA DO "c:/temp/ITEM.txt"
        try{         
            FileReader frITEM = new FileReader("c:/temp/ITEM2.txt");
            BufferedReader brITEM = new BufferedReader(frITEM);
            while((currentLineITEM = brITEM.readLine()) != null){
                dataITEM = currentLineITEM.split("@#@");
                if(dataITEM[4].equals("PRODUTO")){
                    FileReader frLIVRO = new FileReader("c:/temp/LIVRO.txt");
                    BufferedReader brLIVRO = new BufferedReader(frLIVRO);
                    this.qtdEstoque = 0; 
                    while((currentLineLIVRO = brLIVRO.readLine()) != null){
                    dataLIVRO = currentLineLIVRO.split("@#@");
                        if ((dataITEM[0].equals(dataLIVRO[2]))){
                            this.qtdEstoque = this.qtdEstoque + Integer.parseInt(dataLIVRO[3]);
                        }
                    }
                    frLIVRO.close();
                    brLIVRO.close();
//ATULIZAR LINA DO ITEM 
                    atulizar_linha_txt("C:/temp/ITEM.txt", dataITEM[0], 1, "@#@", dataITEM[0], dataITEM[1],Integer.toString(this.qtdEstoque), dataITEM[3], dataITEM[4], dataITEM[5], dataITEM[6], dataITEM[7], dataITEM[8], dataITEM[9], dataITEM[10], dataITEM[11],dataITEM[12], dataITEM[13], dataITEM[14], dataITEM[15], dataITEM[16], dataITEM[17], dataITEM[18],dataITEM[19], dataITEM[20], dataITEM[21], dataITEM[22], dataITEM[23], dataITEM[24], dataITEM[25], dataITEM[26], dataITEM[27], dataITEM[28]);      
//ATULIZAR LINA DO ITEM 
                }
            }
            frITEM.close();
            brITEM.close();
            ////*****EXCLUIR ARQUIVO "c:/temp/ITEM2.txt"
            File oldFile = new File("c:/temp/ITEM2.txt");
            oldFile.delete();  
            ////*****EXCLUIR ARQUIVO "c:/temp/ITEM2.txt"
        }catch(Exception e){
        }
}
   
        public void backup(String arquivo,String arquivocopia){
            data();           
            File source = new File(arquivo);
            File dest = new File(arquivocopia+this.dia+"-"+this.mes+"-"+this.ano);
            if (dest.exists()) {
                System.out.println("JA EXISTE ESSE BACKUP");
            }else{
                 dest.mkdirs();
            //dest.
            //FileUtils.copyDirectory(source, dest);
                System.out.println("CRIADA A PASTA DE BACKUP "+dest);
            }}
        
        
}
