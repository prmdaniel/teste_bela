package CLASSES;
        
import java.awt.Color;
import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class GraficoBarra extends JFrame {
    
public GraficoBarra(){
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setTitle("BARRA grafico");
    setSize(769, 440);
    setLocationRelativeTo(null);
    criarGrafico();
    setVisible(true);
}

public void criarGrafico(){
    
    DefaultCategoryDataset barra = new DefaultCategoryDataset();
    barra.setValue(1200, "PAGOS", "");
    barra.setValue(900, "PENDENTES","PENDENTES");
    barra.setValue(800, "VALORES PAGO","VALORES PAGO");
    barra.setValue(750, "VALORES PENDENTES","VALORES PENDENTES");

    JFreeChart grafico = ChartFactory.createBarChart3D("xxxxx","sssss","wwwww",barra,PlotOrientation.VERTICAL,true,true,false);
    
    CategoryPlot barraitem = grafico.getCategoryPlot();
    //barraitem.getRenderer().setSeriesPaint(0,Color.BLACK);
        barraitem.getRenderer().setBaseItemLabelsVisible(true); 
    //barraitem.getRenderer().setSeriesOutlinePaint(0, Color.BLACK);
    //barraitem.getRenderer().setSeriesOutlineStroke(1, stroke);
          
    ChartPanel painel = new ChartPanel(grafico);
    add(painel);
}


}
