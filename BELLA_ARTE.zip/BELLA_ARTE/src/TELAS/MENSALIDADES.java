package TELAS;

import CLASSES.Txt;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MENSALIDADES extends javax.swing.JFrame {
        int contadorpendente;
        int contadorpagas;
    public MENSALIDADES() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BUSCA1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        me_data_cria = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        pagas = new javax.swing.JCheckBox();
        pendentes = new javax.swing.JCheckBox();
        PIX = new javax.swing.JButton();
        DEBITO = new javax.swing.JButton();
        CREDITO = new javax.swing.JButton();
        EXCLUIR = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        me_nome = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        me_data = new javax.swing.JTextField();
        me_valor = new javax.swing.JTextField();
        DINHEIRO = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        ATUALIZAR = new javax.swing.JButton();
        PENDENTE = new javax.swing.JButton();
        me_filtro_nome = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        me_id = new javax.swing.JTextField();
        me_nome_id = new javax.swing.JTextField();
        me_status = new javax.swing.JTextField();
        me_data_pag = new javax.swing.JTextField();
        me_tipo_pag = new javax.swing.JTextField();
        me_foto = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        me_filtro_data = new javax.swing.JTextField();

        BUSCA1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        BUSCA1.setText("EXCLUIR");
        BUSCA1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BUSCA1ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("(DATA)");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 20, 60, -1));

        me_data_cria.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        me_data_cria.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        me_data_cria.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_data_criaCaretUpdate(evt);
            }
        });
        getContentPane().add(me_data_cria, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 10, 20, 30));

        jTable3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOME", "DATA VENC", "VALOR", "STATUS", "DATA PAG.", "TIPO PG"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable3.setIntercellSpacing(new java.awt.Dimension(10, 1));
        jTable3.setName(""); // NOI18N
        jTable3.setRequestFocusEnabled(false);
        jTable3.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable3.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jTable3MouseDragged(evt);
            }
        });
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jTable3MouseExited(evt);
            }
        });
        jScrollPane1.setViewportView(jTable3);
        if (jTable3.getColumnModel().getColumnCount() > 0) {
            jTable3.getColumnModel().getColumn(0).setResizable(false);
            jTable3.getColumnModel().getColumn(0).setPreferredWidth(20);
            jTable3.getColumnModel().getColumn(1).setResizable(false);
            jTable3.getColumnModel().getColumn(1).setPreferredWidth(220);
            jTable3.getColumnModel().getColumn(2).setResizable(false);
            jTable3.getColumnModel().getColumn(2).setPreferredWidth(60);
            jTable3.getColumnModel().getColumn(3).setResizable(false);
            jTable3.getColumnModel().getColumn(3).setPreferredWidth(40);
            jTable3.getColumnModel().getColumn(4).setResizable(false);
            jTable3.getColumnModel().getColumn(4).setPreferredWidth(60);
            jTable3.getColumnModel().getColumn(5).setResizable(false);
            jTable3.getColumnModel().getColumn(5).setPreferredWidth(50);
            jTable3.getColumnModel().getColumn(6).setResizable(false);
            jTable3.getColumnModel().getColumn(6).setPreferredWidth(50);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 750, 250));

        pagas.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pagas.setForeground(new java.awt.Color(0, 153, 51));
        pagas.setText("PAGAS (0)");
        pagas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pagasActionPerformed(evt);
            }
        });
        getContentPane().add(pagas, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 10, 190, 30));

        pendentes.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pendentes.setSelected(true);
        pendentes.setText("PENDENTES (0)");
        pendentes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pendentesActionPerformed(evt);
            }
        });
        getContentPane().add(pendentes, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 40, 190, 30));

        PIX.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        PIX.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/dinheiro32.png"))); // NOI18N
        PIX.setText("PIX");
        PIX.setBorderPainted(false);
        PIX.setContentAreaFilled(false);
        PIX.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        PIX.setMargin(new java.awt.Insets(2, 0, 2, 14));
        PIX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PIXActionPerformed(evt);
            }
        });
        getContentPane().add(PIX, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 400, 90, 30));

        DEBITO.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        DEBITO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/cartao 2.png"))); // NOI18N
        DEBITO.setText("DEBITO");
        DEBITO.setBorderPainted(false);
        DEBITO.setContentAreaFilled(false);
        DEBITO.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        DEBITO.setMargin(new java.awt.Insets(2, 0, 2, 14));
        DEBITO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DEBITOActionPerformed(evt);
            }
        });
        getContentPane().add(DEBITO, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 400, 130, 30));

        CREDITO.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        CREDITO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/cartao 2.png"))); // NOI18N
        CREDITO.setText("CREDITO");
        CREDITO.setBorderPainted(false);
        CREDITO.setContentAreaFilled(false);
        CREDITO.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        CREDITO.setMargin(new java.awt.Insets(2, 0, 2, 14));
        CREDITO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CREDITOActionPerformed(evt);
            }
        });
        getContentPane().add(CREDITO, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 400, 140, 30));

        EXCLUIR.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        EXCLUIR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/trash_32.png"))); // NOI18N
        EXCLUIR.setBorderPainted(false);
        EXCLUIR.setContentAreaFilled(false);
        EXCLUIR.setDefaultCapable(false);
        EXCLUIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EXCLUIRActionPerformed(evt);
            }
        });
        getContentPane().add(EXCLUIR, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 90, 40, 40));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("ID");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 30, -1));

        me_nome.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        me_nome.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_nomeCaretUpdate(evt);
            }
        });
        getContentPane().add(me_nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, 250, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("DATA VENC.");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 90, 90, -1));

        me_data.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        me_data.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_dataCaretUpdate(evt);
            }
        });
        getContentPane().add(me_data, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 110, 100, -1));

        me_valor.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        me_valor.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_valorCaretUpdate(evt);
            }
        });
        getContentPane().add(me_valor, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 110, 80, -1));

        DINHEIRO.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        DINHEIRO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/dinheiro32.png"))); // NOI18N
        DINHEIRO.setText("DINHEIRO");
        DINHEIRO.setBorderPainted(false);
        DINHEIRO.setContentAreaFilled(false);
        DINHEIRO.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        DINHEIRO.setMargin(new java.awt.Insets(2, 0, 2, 14));
        DINHEIRO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DINHEIROActionPerformed(evt);
            }
        });
        getContentPane().add(DINHEIRO, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 400, 140, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("VALOR");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 90, 60, -1));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/lampada_32.png"))); // NOI18N
        jButton3.setText("GERAR");
        jButton3.setBorderPainted(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setMargin(new java.awt.Insets(2, 0, 2, 14));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, -1, 30));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("FILTRO (NOME)");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 200, -1));

        ATUALIZAR.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        ATUALIZAR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/edit-validated_32.png"))); // NOI18N
        ATUALIZAR.setBorderPainted(false);
        ATUALIZAR.setContentAreaFilled(false);
        ATUALIZAR.setDefaultCapable(false);
        ATUALIZAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ATUALIZARActionPerformed(evt);
            }
        });
        getContentPane().add(ATUALIZAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 90, 40, 40));

        PENDENTE.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        PENDENTE.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/edit-not-32.png"))); // NOI18N
        PENDENTE.setText("PENDENTE");
        PENDENTE.setBorderPainted(false);
        PENDENTE.setContentAreaFilled(false);
        PENDENTE.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        PENDENTE.setMargin(new java.awt.Insets(2, 0, 2, 14));
        PENDENTE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PENDENTEActionPerformed(evt);
            }
        });
        getContentPane().add(PENDENTE, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 400, 140, 30));

        me_filtro_nome.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        me_filtro_nome.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_filtro_nomeCaretUpdate(evt);
            }
        });
        getContentPane().add(me_filtro_nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 310, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("NOME");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 90, 180, -1));

        me_id.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        me_id.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        me_id.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_idCaretUpdate(evt);
            }
        });
        getContentPane().add(me_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 60, -1));

        me_nome_id.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        me_nome_id.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        me_nome_id.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_nome_idCaretUpdate(evt);
            }
        });
        getContentPane().add(me_nome_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 0, 20, 30));

        me_status.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        me_status.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        me_status.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_statusCaretUpdate(evt);
            }
        });
        getContentPane().add(me_status, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 0, 20, 30));

        me_data_pag.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        me_data_pag.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        me_data_pag.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_data_pagCaretUpdate(evt);
            }
        });
        getContentPane().add(me_data_pag, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 10, 20, 30));

        me_tipo_pag.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        me_tipo_pag.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        me_tipo_pag.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_tipo_pagCaretUpdate(evt);
            }
        });
        getContentPane().add(me_tipo_pag, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 0, 20, 30));

        me_foto.setBackground(java.awt.Color.white);
        me_foto.setAlignmentX(5.0F);
        me_foto.setAlignmentY(5.0F);
        me_foto.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        me_foto.setMargin(new java.awt.Insets(0, 0, 0, 0));
        me_foto.setMaximumSize(new java.awt.Dimension(10, 10));
        me_foto.setMinimumSize(new java.awt.Dimension(10, 10));
        me_foto.setOpaque(false);
        me_foto.setPreferredSize(new java.awt.Dimension(100, 100));
        me_foto.setVerifyInputWhenFocusTarget(false);
        me_foto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                me_fotoActionPerformed(evt);
            }
        });
        getContentPane().add(me_foto, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 10, 110, 130));

        jSeparator4.setOpaque(true);
        getContentPane().add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 630, -1));

        me_filtro_data.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        me_filtro_data.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                me_filtro_dataCaretUpdate(evt);
            }
        });
        getContentPane().add(me_filtro_data, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 40, 100, -1));

        setSize(new java.awt.Dimension(785, 479));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    public void filtro_me(){
        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }
        try {
            FileReader fr = new FileReader("c:/temp/MENSALIDADE.txt");
            BufferedReader br = new BufferedReader(fr);
            Object[] lines = br.lines().toArray();
            contadorpendente = 0;
            contadorpagas = 0;
            for (int i = 0; i < lines.length; i++) {
                String[] row = lines[i].toString().split("@#@");
                //model.addRow(row); //ou abaixo
                        if (row[1].toUpperCase().contains(me_filtro_nome.getText().toUpperCase())&&row[3].contains(me_filtro_data.getText().toUpperCase())) {
                        if (pendentes.isSelected()&&pagas.isSelected()){
                           model.addRow(new Object[]{row[0], row[1], row[3], row[4], row[5], row[6], row[7]});
                            if (row[5].equals("PENDENTE")){
                                contadorpendente++;
                            }else{
                                contadorpagas++;
                            }
                        }else{if (pendentes.isSelected()&&row[5].equals("PENDENTE")){
                          model.addRow(new Object[]{row[0], row[1], row[3], row[4], row[5], row[6], row[7]});
                            if (row[5].equals("PENDENTE")){
                                contadorpendente++;
                            }else{
                                contadorpagas++;
                            }
                        }else{if (pagas.isSelected()&&row[5].equals("PAGO")){
                          model.addRow(new Object[]{row[0], row[1], row[3], row[4], row[5], row[6], row[7]}); 
                             if (row[5].equals("PENDENTE")){
                                contadorpendente++;
                            }else{
                                contadorpagas++;
                            }
                        } } } }  
            }
            br.close();
            fr.close();
            
            pagas.setText("PAGAS ("+contadorpagas+")");
            pendentes.setText("PENDENTES ("+contadorpendente+")");
        } catch (FileNotFoundException ex) {  
        } catch (IOException ex) {
        }
    }
    
    private void me_data_criaCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_data_criaCaretUpdate

    }//GEN-LAST:event_me_data_criaCaretUpdate

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
            DefaultTableModel model = (DefaultTableModel) this.jTable3.getModel();
            me_id.setText(model.getValueAt(this.jTable3.getSelectedRow(), 0).toString());
    }//GEN-LAST:event_jTable3MouseClicked

    private void pagasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pagasActionPerformed
        filtro_me();
    }//GEN-LAST:event_pagasActionPerformed

    private void pendentesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pendentesActionPerformed
        filtro_me();
    }//GEN-LAST:event_pendentesActionPerformed

    private void PIXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PIXActionPerformed
              if(me_id.getText().equals("")){
            JOptionPane.showMessageDialog(this, "ITEM NAO SELECIONADO");
        }else{
            if(me_status.getText().equals("PENDENTE")){
            Txt txt = new Txt();
            txt.data();
            txt.atulizar_linha_txt("c:/temp/MENSALIDADE.txt", me_id.getText(), 1 ,"@#@",
                    me_id.getText(),
                    me_nome.getText(),
                    me_nome_id.getText(),
                    me_data.getText(),
                    me_valor.getText(),
                    "PAGO",
                    txt.dia_mes_ano,
                    "PIX",
                    me_data_cria.getText(),
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "fim");
            me_data_cria.setText("");
            me_nome.setText("");
            me_data.setText("");
            me_valor.setText("");
            me_id.setText("");
            filtro_me();
            me_filtro_nome.requestFocus();
            JOptionPane.showMessageDialog(this, "MENSALIDADE ATUALIZADO");
            }
        }  
    }//GEN-LAST:event_PIXActionPerformed

    private void BUSCA1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BUSCA1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BUSCA1ActionPerformed

    private void DEBITOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DEBITOActionPerformed
        if(me_id.getText().equals("")){
            JOptionPane.showMessageDialog(this, "ITEM NAO SELECIONADO");
        }else{
            if(me_status.getText().equals("PENDENTE")){
            Txt txt = new Txt();
            txt.data();
            txt.atulizar_linha_txt("c:/temp/MENSALIDADE.txt", me_id.getText(), 1 ,"@#@",
                    me_id.getText(),
                    me_nome.getText(),
                    me_nome_id.getText(),
                    me_data.getText(),
                    me_valor.getText(),
                    "PAGO",
                    txt.dia_mes_ano,
                    "DEBITO",
                    me_data_cria.getText(),
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "fim");
            me_data_cria.setText("");
            me_nome.setText("");
            me_data.setText("");
            me_valor.setText("");
            me_id.setText("");
            filtro_me();
            me_filtro_nome.requestFocus();
            JOptionPane.showMessageDialog(this, "MENSALIDADE ATUALIZADO");
            
            }
        }   
    }//GEN-LAST:event_DEBITOActionPerformed

    private void CREDITOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CREDITOActionPerformed
              if(me_id.getText().equals("")){
            JOptionPane.showMessageDialog(this, "ITEM NAO SELECIONADO");
        }else{
            if(me_status.getText().equals("PENDENTE")){
            Txt txt = new Txt();
            txt.data();
            txt.atulizar_linha_txt("c:/temp/MENSALIDADE.txt", me_id.getText(), 1 ,"@#@",
                    me_id.getText(),
                    me_nome.getText(),
                    me_nome_id.getText(),
                    me_data.getText(),
                    me_valor.getText(),
                    "PAGO",
                    txt.dia_mes_ano,
                    "CREDITO",
                    me_data_cria.getText(),
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "fim");
            me_data_cria.setText("");
            me_nome.setText("");
            me_data.setText("");
            me_valor.setText("");
            me_id.setText("");
            filtro_me();
            me_filtro_nome.requestFocus();
            JOptionPane.showMessageDialog(this, "MENSALIDADE ATUALIZADO");
            }
        }  
    }//GEN-LAST:event_CREDITOActionPerformed

    private void EXCLUIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EXCLUIRActionPerformed
             if(me_id.getText().equals("")){
            JOptionPane.showMessageDialog(this, "ITEM NAO SELECIONADO");
        }else{
            Txt txt = new Txt();
            txt.removeRecord("c:/temp/MENSALIDADE.txt", me_id.getText(), 0 ,"@#@");
            me_data_cria.setText("");
            me_nome.setText("");
            me_data.setText("");
            me_valor.setText("");
            me_id.setText("");
            JOptionPane.showMessageDialog(this, "CADASTRO EXCLUIDO");
        }
    }//GEN-LAST:event_EXCLUIRActionPerformed

    private void me_nomeCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_nomeCaretUpdate
        // TODO add your handling code here:
    }//GEN-LAST:event_me_nomeCaretUpdate

    private void me_dataCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_dataCaretUpdate
        // TODO add your handling code here:
    }//GEN-LAST:event_me_dataCaretUpdate

    private void me_valorCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_valorCaretUpdate
        // TODO add your handling code here:
    }//GEN-LAST:event_me_valorCaretUpdate

    private void DINHEIROActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DINHEIROActionPerformed
           if(me_id.getText().equals("")){
            JOptionPane.showMessageDialog(this, "ITEM NAO SELECIONADO");
        }else{
            if(me_status.getText().equals("PENDENTE")){
            Txt txt = new Txt();
            txt.data();
            txt.atulizar_linha_txt("c:/temp/MENSALIDADE.txt", me_id.getText(), 1 ,"@#@",
                    me_id.getText(),
                    me_nome.getText(),
                    me_nome_id.getText(),
                    me_data.getText(),
                    me_valor.getText(),
                    "PAGO",
                    txt.dia_mes_ano,
                    "DINHEIRO",
                    me_data_cria.getText(),
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "fim");
            me_data_cria.setText("");
            me_nome.setText("");
            me_data.setText("");
            me_valor.setText("");
            me_id.setText("");
            filtro_me();
            me_filtro_nome.requestFocus();
            JOptionPane.showMessageDialog(this, "MENSALIDADE ATUALIZADO");
            }
        }  
    }//GEN-LAST:event_DINHEIROActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        new GERADOR().setVisible(true);      
    }//GEN-LAST:event_jButton3ActionPerformed

    private void ATUALIZARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ATUALIZARActionPerformed
              if(me_id.getText().equals("")){
            JOptionPane.showMessageDialog(this, "ITEM NAO SELECIONADO");
        }else{
            Txt txt = new Txt();
            txt.data();
            txt.atulizar_linha_txt("c:/temp/MENSALIDADE.txt", me_id.getText(), 1 ,"@#@",
                    me_id.getText(),
                    me_nome.getText(),
                    me_nome_id.getText(),
                    me_data.getText(),
                    me_valor.getText(),
                    me_status.getText(),
                    me_data_pag.getText(),
                    me_tipo_pag.getText(),
                    me_data_cria.getText(),
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "fim");
            me_data_cria.setText("");
            me_nome.setText("");
            me_data.setText("");
            me_valor.setText("");
            me_id.setText("");
            filtro_me();
            me_filtro_nome.requestFocus();
            JOptionPane.showMessageDialog(this, "MENSALIDADE ATUALIZADO");           
        }  
    }//GEN-LAST:event_ATUALIZARActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        Txt txt = new Txt();
        txt.data();
        me_data_cria.setText(txt.mes);
            me_data_pag.setVisible(false);
            me_data_cria.setVisible(false);
            me_nome_id.setVisible(false);
            me_status.setVisible(false);
            me_tipo_pag.setVisible(false);
        filtro_me();
    }//GEN-LAST:event_formWindowActivated

   
    private void PENDENTEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PENDENTEActionPerformed
               if(me_id.getText().equals("")){
            JOptionPane.showMessageDialog(this, "ITEM NAO SELECIONADO");
        }else{
            if(me_status.getText().equals("PAGO")){
            Txt txt = new Txt();
            txt.data();
            txt.atulizar_linha_txt("c:/temp/MENSALIDADE.txt", me_id.getText(), 1 ,"@#@",
                    me_id.getText(),
                    me_nome.getText(),
                    me_nome_id.getText(),
                    me_data.getText(),
                    me_valor.getText(),
                    "PENDENTE",
                    "",
                    "",
                    me_data_cria.getText(),
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "fim");
            me_data_cria.setText("");
            me_nome.setText("");
            me_data.setText("");
            me_valor.setText("");
            me_id.setText("");
            filtro_me();
            me_filtro_nome.requestFocus();
            JOptionPane.showMessageDialog(this, "MENSALIDADE ATUALIZADO");
            }
        }  
    }//GEN-LAST:event_PENDENTEActionPerformed

    private void me_filtro_nomeCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_filtro_nomeCaretUpdate
        filtro_me();
    }//GEN-LAST:event_me_filtro_nomeCaretUpdate

    private void me_idCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_idCaretUpdate
        try {
            FileReader fr = new FileReader("c:/temp/MENSALIDADE.txt");
            BufferedReader br = new BufferedReader(fr);
            Object[] lines = br.lines().toArray();
            me_data_cria.setText("");
            me_nome.setText("");
            me_data.setText("");
            me_valor.setText("");
            
            for (int i = 0; i < lines.length; i++) {
                String[] row = lines[i].toString().split("@#@");
                if (row[0].equals(me_id.getText())){
                    me_nome.setText(row[1]);
                    me_nome_id.setText(row[2]);
                    me_data.setText(row[3]);
                    me_valor.setText(row[4]);
                    me_status.setText(row[5]);
                    me_data_pag.setText(row[6]);
                    me_tipo_pag.setText(row[7]);
                    me_data_cria.setText(row[8]);
                    Txt txt = new Txt();
                    txt.carregarFoto("c:/temp/ALUNO.txt","@#@",row[2]);
                    System.out.println(txt.caminho_foto);
                        try {
                            ImageIcon icon = new ImageIcon(txt.caminho_foto);
                            icon.setImage(icon.getImage().getScaledInstance(me_foto.getWidth(), me_foto.getHeight(), 1));
                            me_foto.setIcon(icon);     
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(this, "erro foto");
                        }     
                }       
            }
            br.close();
            fr.close();
        } catch (FileNotFoundException ex) {
             System.out.println("ARQUIVO NAO ENCONTRADO");
        } catch (IOException ex) {
            Logger.getLogger(MENSALIDADES.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_me_idCaretUpdate

    private void me_nome_idCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_nome_idCaretUpdate
        // TODO add your handling code here:
    }//GEN-LAST:event_me_nome_idCaretUpdate

    private void me_statusCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_statusCaretUpdate
        // TODO add your handling code here:
    }//GEN-LAST:event_me_statusCaretUpdate

    private void me_data_pagCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_data_pagCaretUpdate
        // TODO add your handling code here:
    }//GEN-LAST:event_me_data_pagCaretUpdate

    private void me_tipo_pagCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_tipo_pagCaretUpdate
        // TODO add your handling code here:
    }//GEN-LAST:event_me_tipo_pagCaretUpdate

    private void jTable3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseExited
    }//GEN-LAST:event_jTable3MouseExited

    private void jTable3MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseDragged
                 DefaultTableModel model = (DefaultTableModel) this.jTable3.getModel();
            me_id.setText(model.getValueAt(this.jTable3.getSelectedRow(), 0).toString());
    }//GEN-LAST:event_jTable3MouseDragged

    private void me_fotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_me_fotoActionPerformed

    }//GEN-LAST:event_me_fotoActionPerformed

    private void me_filtro_dataCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_me_filtro_dataCaretUpdate
          filtro_me();
    }//GEN-LAST:event_me_filtro_dataCaretUpdate


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MENSALIDADES.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MENSALIDADES.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MENSALIDADES.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MENSALIDADES.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MENSALIDADES().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ATUALIZAR;
    private javax.swing.JButton BUSCA1;
    private javax.swing.JButton CREDITO;
    private javax.swing.JButton DEBITO;
    private javax.swing.JButton DINHEIRO;
    private javax.swing.JButton EXCLUIR;
    private javax.swing.JButton PENDENTE;
    private javax.swing.JButton PIX;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField me_data;
    private javax.swing.JTextField me_data_cria;
    private javax.swing.JTextField me_data_pag;
    private javax.swing.JTextField me_filtro_data;
    private javax.swing.JTextField me_filtro_nome;
    public javax.swing.JButton me_foto;
    private javax.swing.JTextField me_id;
    private javax.swing.JTextField me_nome;
    private javax.swing.JTextField me_nome_id;
    private javax.swing.JTextField me_status;
    private javax.swing.JTextField me_tipo_pag;
    private javax.swing.JTextField me_valor;
    private javax.swing.JCheckBox pagas;
    private javax.swing.JCheckBox pendentes;
    // End of variables declaration//GEN-END:variables
}
