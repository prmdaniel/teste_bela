package TELAS;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class BUSCA_ALUNO extends javax.swing.JFrame {

    public BUSCA_ALUNO() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        filtro_nome = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        filtro_idade = new javax.swing.JTextField();
        PENDENTE = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("FILTRO PELO NOME");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 180, -1));

        filtro_nome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filtro_nome.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                filtro_nomeCaretUpdate(evt);
            }
        });
        filtro_nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filtro_nomeActionPerformed(evt);
            }
        });
        getContentPane().add(filtro_nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 210, -1));

        jTable2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOME", "IDADE", "STATUS", "ENDEREÇO", "MENSAL", "AULA"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setIntercellSpacing(new java.awt.Dimension(10, 1));
        jTable2.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jTable2MouseDragged(evt);
            }
        });
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setResizable(false);
            jTable2.getColumnModel().getColumn(0).setPreferredWidth(50);
            jTable2.getColumnModel().getColumn(1).setResizable(false);
            jTable2.getColumnModel().getColumn(1).setPreferredWidth(250);
            jTable2.getColumnModel().getColumn(2).setResizable(false);
            jTable2.getColumnModel().getColumn(2).setPreferredWidth(120);
            jTable2.getColumnModel().getColumn(3).setResizable(false);
            jTable2.getColumnModel().getColumn(3).setPreferredWidth(100);
            jTable2.getColumnModel().getColumn(4).setResizable(false);
            jTable2.getColumnModel().getColumn(4).setPreferredWidth(200);
            jTable2.getColumnModel().getColumn(5).setResizable(false);
            jTable2.getColumnModel().getColumn(5).setPreferredWidth(80);
            jTable2.getColumnModel().getColumn(6).setResizable(false);
            jTable2.getColumnModel().getColumn(6).setPreferredWidth(120);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 750, 370));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("IDADE");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 70, -1));

        filtro_idade.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filtro_idade.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                filtro_idadeCaretUpdate(evt);
            }
        });
        getContentPane().add(filtro_idade, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 30, 80, -1));

        PENDENTE.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        PENDENTE.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/ok_32.png"))); // NOI18N
        PENDENTE.setText("SELECIONAR");
        PENDENTE.setBorderPainted(false);
        PENDENTE.setContentAreaFilled(false);
        PENDENTE.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        PENDENTE.setMargin(new java.awt.Insets(2, 0, 2, 14));
        PENDENTE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PENDENTEActionPerformed(evt);
            }
        });
        getContentPane().add(PENDENTE, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 20, 150, 30));

        setSize(new java.awt.Dimension(786, 479));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
      //  lerTXT(jTable2);
    
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }
        try {
            FileReader fr = new FileReader("c:/temp/ALUNO.txt");
            BufferedReader br = new BufferedReader(fr);
            Object[] lines = br.lines().toArray();
            for (int i = 0; i < lines.length; i++) {
                String[] row = lines[i].toString().split("@#@");
                //model.addRow(row); //ou abaixo
                  model.addRow(new Object[]{row[0], row[1], row[2], row[6], row[13], row[17], row[19]});       
            }
            br.close();
            fr.close();
        } catch (FileNotFoundException ex) {  
        } catch (IOException ex) {
        }
      
    }//GEN-LAST:event_formWindowActivated
    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        if (evt.getClickCount() == 2) {
            DefaultTableModel model = (DefaultTableModel) this.jTable2.getModel();
            TELAS.CADASTRO_ALUNO.tx_id.setText(model.getValueAt(this.jTable2.getSelectedRow(), 0).toString());
            this.dispose();
        }
    }//GEN-LAST:event_jTable2MouseClicked
        
    private void filtro_nomeCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_filtro_nomeCaretUpdate
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }
        try {
            FileReader fr = new FileReader("c:/temp/ALUNO.txt");
            BufferedReader br = new BufferedReader(fr);
            Object[] lines = br.lines().toArray();
            filtro_idade.setText("");            
            for (int i = 0; i < lines.length; i++) {
                String[] row = lines[i].toString().split("@#@");
                if (row[1].toUpperCase().contains(filtro_nome.getText().toUpperCase())) {
                    model.addRow(new Object[]{row[0], row[1], row[2], row[6], row[13], row[17], row[19]});
                }
            }
            br.close();
            fr.close();
        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {
        }
    }//GEN-LAST:event_filtro_nomeCaretUpdate

    private void filtro_idadeCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_filtro_idadeCaretUpdate
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }
        try {
            FileReader fr = new FileReader("c:/temp/ALUNO.txt");
            BufferedReader br = new BufferedReader(fr);
            Object[] lines = br.lines().toArray();    
            filtro_nome.setText("");  
            for (int i = 0; i < lines.length; i++) {
                String[] row = lines[i].toString().split("@#@");
                if (row[2].toUpperCase().contains(filtro_idade.getText().toUpperCase())) {
                    model.addRow(new Object[]{row[0], row[1], row[2], row[6], row[13], row[17], row[19]});
                }
            }
            br.close();
            fr.close();
        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {
        }
    }//GEN-LAST:event_filtro_idadeCaretUpdate

    private void filtro_nomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filtro_nomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_filtro_nomeActionPerformed

    private void jTable2MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseDragged
        if (evt.getClickCount() == 2) {
            DefaultTableModel model = (DefaultTableModel) this.jTable2.getModel();
            TELAS.CADASTRO_ALUNO.tx_id.setText(model.getValueAt(this.jTable2.getSelectedRow(), 0).toString());
            this.dispose();
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jTable2MouseDragged

    private void PENDENTEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PENDENTEActionPerformed
         if (jTable2.getSelectedRow() == -1) {
         }else{
            DefaultTableModel model = (DefaultTableModel) this.jTable2.getModel();
            TELAS.CADASTRO_ALUNO.tx_id.setText(model.getValueAt(this.jTable2.getSelectedRow(), 0).toString());
            this.dispose();
        }
    }//GEN-LAST:event_PENDENTEActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton PENDENTE;
    private javax.swing.JTextField filtro_idade;
    private javax.swing.JTextField filtro_nome;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable2;
    // End of variables declaration//GEN-END:variables

}
