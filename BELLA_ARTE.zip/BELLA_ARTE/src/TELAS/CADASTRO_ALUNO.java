package TELAS;

import CLASSES.Txt;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class CADASTRO_ALUNO extends javax.swing.JFrame {

    private static JTextField xxx;
    
    public CADASTRO_ALUNO() {
        initComponents();
    }
      
    public void limpar_caixas(){
                    tx_nome_aluno.setText("");
                    tx_idade_aluno.setText("");
                    tx_cpf_aluno.setText("");
                    tx_rg_aluno.setText("");
                    tx_telefone_aluno.setText("");
                    tx_status.setSelectedIndex(0);      // tx_status1.setText("") tx_status.setSelectedIndex(0);
                    tx_nome_res.setText("");
                    tx_idade_res.setText("");
                    tx_cpf_res.setText("");
                    tx_rg_res.setText("");
                    tx_telefone_res.setText("");
                    tx_email_res.setText("");
                    tx_end.setText("");
                    tx_numero.setText("");
                    tx_cep.setText("");
                    tx_bairro.setText("");
                    tx_mensal.setText("");
                    tx_dia_v.setText("");
                    tx_aula.setText(""); 
                    tx_foto_caminho.setText(""); 
                    tx_data_cria.setText(""); 
                    try {
                        tx_foto.setIcon(null);     
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "erro foto metodo limpar");
                    }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tx_id = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        tx_nome_aluno = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        tx_idade_aluno = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        tx_cpf_aluno = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        tx_end = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tx_cep = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tx_telefone_aluno = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        tx_nome_res = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        tx_cpf_res = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        tx_bairro = new javax.swing.JTextField();
        tx_numero = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        tx_rg_res = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        tx_mensal = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        tx_dia_v = new javax.swing.JTextField();
        BUSCA = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        tx_idade_res = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        tx_rg_aluno = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        tx_telefone_res = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        NOVO = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel21 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        tx_aula = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        tx_email_res = new javax.swing.JTextField();
        EXCLUIR = new javax.swing.JButton();
        tx_foto = new javax.swing.JButton();
        tx_foto_caminho = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        tx_data_cria = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        tx_status = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tx_id.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tx_id.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tx_id.setMargin(new java.awt.Insets(2, 5, 2, 2));
        tx_id.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                tx_idCaretUpdate(evt);
            }
        });
        getContentPane().add(tx_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 60, 50, -1));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/thearrow_32.png"))); // NOI18N
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 160, 60, 40));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("NOME DO ALUNO");
        jLabel2.setOpaque(true);
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 210, 20));

        tx_nome_aluno.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_nome_aluno.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_nome_aluno, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 370, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("ESTATUS");
        jLabel3.setOpaque(true);
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 40, -1, 20));

        tx_idade_aluno.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_idade_aluno.setToolTipText("");
        tx_idade_aluno.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_idade_aluno, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 120, 100, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("CPF");
        jLabel5.setOpaque(true);
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 70, -1));

        tx_cpf_aluno.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_cpf_aluno.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_cpf_aluno, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 120, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("ENDEREÇO");
        jLabel6.setOpaque(true);
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 250, 20));

        tx_end.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_end.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_end, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 310, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("CEP");
        jLabel7.setOpaque(true);
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 320, 60, 20));

        tx_cep.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_cep.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_cep, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 340, 100, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("TELEFONE");
        jLabel8.setOpaque(true);
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 150, 100, -1));

        tx_telefone_aluno.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_telefone_aluno.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_telefone_aluno, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, 120, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("NOME DO RESPONSAVEL");
        jLabel9.setOpaque(true);
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 180, 20));

        tx_nome_res.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_nome_res.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_nome_res, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 370, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setText("CPF");
        jLabel10.setOpaque(true);
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 70, 20));

        tx_cpf_res.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_cpf_res.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_cpf_res, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 120, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setText("BAIRRO");
        jLabel11.setOpaque(true);
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 320, 70, 20));

        tx_bairro.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_bairro.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_bairro, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 340, 140, -1));

        tx_numero.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_numero.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_numero, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 340, 50, -1));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Next_arrow_32.png"))); // NOI18N
        jButton3.setBorderPainted(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setFocusable(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 160, 60, 40));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setText("RG");
        jLabel13.setOpaque(true);
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 260, 70, 20));

        tx_rg_res.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_rg_res.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_rg_res, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 280, 110, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("MESAL");
        jLabel14.setOpaque(true);
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 70, 20));

        tx_mensal.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_mensal.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_mensal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, 80, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setText("DIA V.");
        jLabel15.setOpaque(true);
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 380, 50, 20));

        tx_dia_v.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_dia_v.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_dia_v, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 400, 70, -1));

        BUSCA.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        BUSCA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Search_64.png"))); // NOI18N
        BUSCA.setText("BUSCA");
        BUSCA.setBorderPainted(false);
        BUSCA.setContentAreaFilled(false);
        BUSCA.setFocusable(false);
        BUSCA.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        BUSCA.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BUSCA.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BUSCA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BUSCAActionPerformed(evt);
            }
        });
        getContentPane().add(BUSCA, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 90, 90));

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/edit-validated_64.png"))); // NOI18N
        jButton6.setText("ALTERAR");
        jButton6.setBorderPainted(false);
        jButton6.setContentAreaFilled(false);
        jButton6.setFocusable(false);
        jButton6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton6.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 0, 100, 90));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setText("IDADE");
        jLabel16.setOpaque(true);
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 210, -1, 20));

        tx_idade_res.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_idade_res.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_idade_res, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 230, 100, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel17.setText("RG");
        jLabel17.setOpaque(true);
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 70, -1));

        tx_rg_aluno.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_rg_aluno.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_rg_aluno, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 170, 110, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel18.setText("TELEFONE");
        jLabel18.setOpaque(true);
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, 100, 20));

        tx_telefone_res.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_telefone_res.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_telefone_res, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 280, 120, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 600, 10));

        jSeparator2.setOpaque(true);
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 750, -1));

        NOVO.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        NOVO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/novo_64.png"))); // NOI18N
        NOVO.setText("NOVO");
        NOVO.setBorderPainted(false);
        NOVO.setContentAreaFilled(false);
        NOVO.setFocusable(false);
        NOVO.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        NOVO.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        NOVO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NOVOActionPerformed(evt);
            }
        });
        getContentPane().add(NOVO, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 0, 90, 90));

        jSeparator3.setOpaque(true);
        getContentPane().add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 750, -1));

        jSeparator4.setOpaque(true);
        getContentPane().add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 750, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel21.setText("Nº");
        jLabel21.setOpaque(true);
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 320, 30, 20));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel20.setText("AULA");
        jLabel20.setOpaque(true);
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 380, 70, 20));

        tx_aula.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_aula.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_aula, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 400, 200, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel22.setText("E-MAIL");
        jLabel22.setOpaque(true);
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 260, 90, 20));

        tx_email_res.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_email_res.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_email_res, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 280, 220, -1));

        EXCLUIR.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        EXCLUIR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/trash_64.png"))); // NOI18N
        EXCLUIR.setText("EXCLUIR");
        EXCLUIR.setBorderPainted(false);
        EXCLUIR.setContentAreaFilled(false);
        EXCLUIR.setFocusable(false);
        EXCLUIR.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EXCLUIR.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        EXCLUIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EXCLUIRActionPerformed(evt);
            }
        });
        getContentPane().add(EXCLUIR, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 0, 100, 90));

        tx_foto.setBackground(java.awt.Color.white);
        tx_foto.setAlignmentX(5.0F);
        tx_foto.setAlignmentY(5.0F);
        tx_foto.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tx_foto.setMargin(new java.awt.Insets(0, 0, 0, 0));
        tx_foto.setMaximumSize(new java.awt.Dimension(10, 10));
        tx_foto.setMinimumSize(new java.awt.Dimension(10, 10));
        tx_foto.setOpaque(false);
        tx_foto.setPreferredSize(new java.awt.Dimension(100, 100));
        tx_foto.setVerifyInputWhenFocusTarget(false);
        tx_foto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tx_fotoActionPerformed(evt);
            }
        });
        getContentPane().add(tx_foto, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 0, 140, 160));

        tx_foto_caminho.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        tx_foto_caminho.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tx_foto_caminho.setOpaque(false);
        tx_foto_caminho.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                tx_foto_caminhoCaretUpdate(evt);
            }
        });
        getContentPane().add(tx_foto_caminho, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 100, 40, -1));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel23.setText("DATA CAD.");
        jLabel23.setOpaque(true);
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 380, 90, 20));

        tx_data_cria.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tx_data_cria.setMargin(new java.awt.Insets(2, 5, 2, 2));
        getContentPane().add(tx_data_cria, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 400, 110, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("IDADE");
        jLabel4.setOpaque(true);
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 100, -1, 20));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setText("ID");
        jLabel12.setOpaque(true);
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 40, -1, 20));

        tx_status.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tx_status.setMaximumRowCount(15);
        tx_status.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ATIVO", "INATIVO" }));
        tx_status.setToolTipText("");
        getContentPane().add(tx_status, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 60, 120, -1));

        setSize(new java.awt.Dimension(786, 479));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (tx_id.getText().equals("")){   
            tx_id.setText("1");
        }else{
            int id_valor = Integer.parseInt(tx_id.getText());
            if (id_valor == 1){    
            }else{
            id_valor --;
            tx_id.setText(Integer.toString(id_valor));
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (tx_id.getText().equals("")){ 
            tx_id.setText("1");
        }else{
            int id_valor = Integer.parseInt(tx_id.getText());
            id_valor ++;
            tx_id.setText(Integer.toString(id_valor));
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void BUSCAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BUSCAActionPerformed
        new BUSCA_ALUNO().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_BUSCAActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        if(tx_id.getText().equals("")){
            JOptionPane.showMessageDialog(this, "ITEM NAO SELECIONADO");
        }else{
            Txt txt = new Txt();
            txt.data();
            
            String dataInativado="";
            if (tx_status.getSelectedItem().toString().equals("INATIVO")){
                dataInativado = txt.dia_mes_ano;
            }
            
            txt.atulizar_linha_txt("c:/temp/ALUNO.txt", tx_id.getText(), 1 ,"@#@",
                    tx_id.getText(),
                    tx_nome_aluno.getText(),
                    tx_idade_aluno.getText(),
                    tx_cpf_aluno.getText(),
                    tx_rg_aluno.getText(),
                    tx_telefone_aluno.getText(),
                    tx_status.getSelectedItem().toString(), //tx_status1.getText() tx_status.getSelectedItem().toString()
                    tx_nome_res.getText(),
                    tx_idade_res.getText(),
                    tx_cpf_res.getText(),
                    tx_rg_res.getText(),
                    tx_telefone_res.getText(),
                    tx_email_res.getText(),
                    tx_end.getText(),
                    tx_numero.getText(),
                    tx_cep.getText(),
                    tx_bairro.getText(),
                    tx_mensal.getText(),
                    tx_dia_v.getText(),
                    tx_aula.getText(),
                    tx_foto_caminho.getText(),
                    tx_data_cria.getText(),
                    dataInativado,
                    "",
                    "",
                    "",
                    "",
                    "",
                    "fim");
            limpar_caixas();
            tx_id.setText("");
            JOptionPane.showMessageDialog(this, "CADASTRO ATUALIZADO");
        }   
    }//GEN-LAST:event_jButton6ActionPerformed

    private void NOVOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NOVOActionPerformed
        if(tx_nome_aluno.getText().equals("") || tx_mensal.getText().equals("") || tx_dia_v.getText().equals("")){
            JOptionPane.showMessageDialog(this, "PREENCHA OS CAMPOS PARA PODER GRAVAR");
        }else{
            Txt txt = new Txt();
            txt.data();
            txt.ultimo_registro("c:/temp/ALUNO.txt","@#@");          
            txt.grava_ultima_linha("c:/temp/ALUNO.txt","@#@", 
                    txt.novo_registro,
                    tx_nome_aluno.getText(),
                    tx_idade_aluno.getText(),
                    tx_cpf_aluno.getText(),
                    tx_rg_aluno.getText(),
                    tx_telefone_aluno.getText(),
                    tx_status.getSelectedItem().toString(), //tx_status1.getText() tx_status.getSelectedItem().toString()
                    tx_nome_res.getText(),
                    tx_idade_res.getText(),
                    tx_cpf_res.getText(),
                    tx_rg_res.getText(),
                    tx_telefone_res.getText(),
                    tx_email_res.getText(),
                    tx_end.getText(),
                    tx_numero.getText(),
                    tx_cep.getText(),
                    tx_bairro.getText(),
                    tx_mensal.getText(),
                    tx_dia_v.getText(),
                    tx_aula.getText(),
                    tx_foto_caminho.getText(),
                    txt.dia_mes_ano,
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "fim");
            limpar_caixas();
            tx_id.setText("");
            JOptionPane.showMessageDialog(this, "USUARIO CADASTRADO");
            
        }
    }//GEN-LAST:event_NOVOActionPerformed

    private void EXCLUIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EXCLUIRActionPerformed
        if(tx_id.getText().equals("")){
            JOptionPane.showMessageDialog(this, "ITEM NAO SELECIONADO");
        }else{
            Txt txt = new Txt();
            txt.removeRecord("c:/temp/ALUNO.txt", tx_id.getText(), 0 ,"@#@");
            limpar_caixas();
            tx_id.setText("");
            JOptionPane.showMessageDialog(this, "CADASTRO EXCLUIDO");
        }
    }//GEN-LAST:event_EXCLUIRActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        tx_foto_caminho.setVisible(false);
    }//GEN-LAST:event_formWindowActivated

    private void tx_idCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_tx_idCaretUpdate
        
        try {
            FileReader fr = new FileReader("c:/temp/ALUNO.txt");
            BufferedReader br = new BufferedReader(fr);
            Object[] lines = br.lines().toArray();
            limpar_caixas();
            for (int i = 0; i < lines.length; i++) {
                String[] row = lines[i].toString().split("@#@");
                //model.addRow(row); //ou abaixo
                if (row[0].equals(tx_id.getText())){
                    tx_nome_aluno.setText(row[1]);
                    tx_idade_aluno.setText(row[2]);
                    tx_cpf_aluno.setText(row[3]);
                    tx_rg_aluno.setText(row[4]);
                    tx_telefone_aluno.setText(row[5]);
                        if(row[6].equals("ATIVO")){
                             tx_status.setSelectedIndex(0); // tx_status1.setText("") tx_status.setSelectedIndex(0);
                        }else{
                             tx_status.setSelectedIndex(1); // tx_status1.setText("") tx_status.setSelectedIndex(0);
                        }
                    tx_nome_res.setText(row[7]);
                    tx_idade_res.setText(row[8]);
                    tx_cpf_res.setText(row[9]);
                    tx_rg_res.setText(row[10]);
                    tx_telefone_res.setText(row[11]);
                    tx_email_res.setText(row[12]);
                    tx_end.setText(row[13]);
                    tx_numero.setText(row[14]);
                    tx_cep.setText(row[15]);
                    tx_bairro.setText(row[16]);
                    tx_mensal.setText(row[17]);
                    tx_dia_v.setText(row[18]);
                    tx_aula.setText(row[19]);   
                    tx_foto_caminho.setText(row[20]); 
                    tx_data_cria.setText(row[21]); 
                        try {
                            ImageIcon icon = new ImageIcon(row[20]);
                            icon.setImage(icon.getImage().getScaledInstance(tx_foto.getWidth(), tx_foto.getHeight(), 1));
                            tx_foto.setIcon(icon);     
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(this, "erro foto");
                        }           
                }       
            }

            br.close();
            fr.close();

        } catch (FileNotFoundException ex) {
             System.out.println("ARQUIVO NAO ENCONTRADO");
        } catch (IOException ex) {
              System.out.println("SSSSS");
        }
    }//GEN-LAST:event_tx_idCaretUpdate

    private void tx_fotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tx_fotoActionPerformed
            if(tx_id.getText().equals("")){
               JOptionPane.showMessageDialog(this, "SELECIONE UM CADASRTO");
            }else{
            JFileChooser file = new JFileChooser("C:\\temp");
            file.setFileSelectionMode(JFileChooser.FILES_ONLY);
            int i= file.showSaveDialog(null);
        if (i==1){
            System.out.println("ARQUIVO NAO SELECIONADO");
        } else {
            File arquivo = file.getSelectedFile();
            System.out.println(arquivo.getPath());
            tx_foto_caminho.setText(arquivo.getPath());
            try {    
                ImageIcon icon = new ImageIcon(tx_foto_caminho.getText());
                icon.setImage(icon.getImage().getScaledInstance(tx_foto.getWidth(), tx_foto.getHeight(), 1));
                tx_foto.setIcon(icon);     
            } catch (Exception ex) {
            }
            }
            }
    }//GEN-LAST:event_tx_fotoActionPerformed

    private void tx_foto_caminhoCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_tx_foto_caminhoCaretUpdate
        // TODO add your handling code here:
    }//GEN-LAST:event_tx_foto_caminhoCaretUpdate

   
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CADASTRO_ALUNO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CADASTRO_ALUNO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CADASTRO_ALUNO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CADASTRO_ALUNO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                new CADASTRO_ALUNO().setVisible(true);
                
            }
        });
    }

 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BUSCA;
    private javax.swing.JButton EXCLUIR;
    private javax.swing.JButton NOVO;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    public static javax.swing.JTextField tx_aula;
    public static javax.swing.JTextField tx_bairro;
    public static javax.swing.JTextField tx_cep;
    public static javax.swing.JTextField tx_cpf_aluno;
    public static javax.swing.JTextField tx_cpf_res;
    public static javax.swing.JTextField tx_data_cria;
    public static javax.swing.JTextField tx_dia_v;
    public static javax.swing.JTextField tx_email_res;
    public static javax.swing.JTextField tx_end;
    public javax.swing.JButton tx_foto;
    public static javax.swing.JTextField tx_foto_caminho;
    public static javax.swing.JTextField tx_id;
    public static javax.swing.JTextField tx_idade_aluno;
    public static javax.swing.JTextField tx_idade_res;
    public static javax.swing.JTextField tx_mensal;
    public static javax.swing.JTextField tx_nome_aluno;
    public static javax.swing.JTextField tx_nome_res;
    public static javax.swing.JTextField tx_numero;
    public static javax.swing.JTextField tx_rg_aluno;
    public static javax.swing.JTextField tx_rg_res;
    public static javax.swing.JComboBox<String> tx_status;
    public static javax.swing.JTextField tx_telefone_aluno;
    public static javax.swing.JTextField tx_telefone_res;
    // End of variables declaration//GEN-END:variables

}
