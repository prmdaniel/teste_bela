package TELAS;

import CLASSES.Txt;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

public class GERADOR extends javax.swing.JFrame {

String novo_registroM;

    public GERADOR() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BUSCA4 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BUSCA4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        BUSCA4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/new-file_64.png"))); // NOI18N
        BUSCA4.setText("GERAR");
        BUSCA4.setBorderPainted(false);
        BUSCA4.setContentAreaFilled(false);
        BUSCA4.setMargin(new java.awt.Insets(2, 0, 2, 14));
        BUSCA4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BUSCA4ActionPerformed(evt);
            }
        });
        getContentPane().add(BUSCA4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 110, 160, 70));

        jComboBox1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2020", "2021", "2022", "2023", "2024", "2025", "2026" }));
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 130, 90, 40));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("ANO");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 60, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("NOME DO ALUNO");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 180, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setText("MES");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 60, -1));

        jComboBox2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jComboBox2.setMaximumRowCount(15);
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TODOS OS ALUNOS" }));
        jComboBox2.setToolTipText("");
        getContentPane().add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 390, -1));

        jComboBox3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        getContentPane().add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 70, 40));

        setSize(new java.awt.Dimension(432, 226));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BUSCA4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BUSCA4ActionPerformed
Txt txt = new Txt();                        
        try{  
            String currentLine;
            String data[];
            FileReader fr1 = new FileReader("c:/temp/ALUNO.txt");
            BufferedReader br1 = new BufferedReader(fr1);
            while((currentLine = br1.readLine()) != null){
                data = currentLine.split("@#@");
if (data[6].equals("ATIVO")){                
txt.registroJaFoiGravado("C:/temp/MENSALIDADE.txt","@#@",1,data[1],2,data[0],3,data[18]+"/"+jComboBox3.getSelectedItem()+"/"+jComboBox1.getSelectedItem()); //men/alu  
if (txt.existe_arquivo.equals("NAO")){
                String x3 = data[0]; //ID ALUNO
                String x2 = data[1]; //NOME
                String ATIVO = data[6]; //ATIVO
                String x5 = data[17]; //VALOR
                String x4 = data[18]+"/"+jComboBox3.getSelectedItem()+"/"+jComboBox1.getSelectedItem(); //DATA VENC
                try{         
                    FileWriter fw = new FileWriter("c:/temp/MENSALIDADE.txt",true); // true = GRAVA NA ULTIMA LINHA
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter pw = new PrintWriter(bw);
                        String xx = "@#@";
txt.ultimo_registro("C:/temp/MENSALIDADE.txt", "@#@");//(String filepath, String delimiter);
                        String x1 = txt.novo_registro; //ID MESALIDADE                    
                        String x6 = "PENDENTE"; //STATUS
                        String x7 = ""; //DATA PG
                        String x8 = ""; //TIPO PG
txt.data();
                        String x9 = txt.dia_mes_ano; //DATA CRIAÇAO
                                if (jComboBox2.getSelectedItem().equals("TODOS OS ALUNOS")){
                                    String xxx = x1+xx+x2+xx+x3+xx+x4+xx+x5+xx+x6+xx+x7+xx+x8+xx+x9+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+"fim";
                                    pw.println(xxx);   
                                }else{
                                    if (jComboBox2.getSelectedItem().equals(data[0]+" - "+data[1])){
                                    String xxx = x1+xx+x2+xx+x3+xx+x4+xx+x5+xx+x6+xx+x7+xx+x8+xx+x9+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+xx+"fim";
                                    pw.println(xxx);  
                                    }//IF
                                }//IF
                    pw.flush();
                    pw.close();
                    bw.close();
                    fw.close();
                  }catch(Exception e){
                  } 
}//IF
}//IF
                }//WHILE
                br1.close();
                fr1.close();
                dispose();
        }catch(Exception e){
        }    
        
    }//GEN-LAST:event_BUSCA4ActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        Txt txt = new Txt();
        txt.data();
        jComboBox3.setSelectedIndex(Integer.parseInt(txt.mes)-1);
        jComboBox1.setSelectedIndex(Integer.parseInt(txt.ano)-2020);
            
        try{ 
            String currentLine;
            String data[];
            FileReader fr1 = new FileReader("c:/temp/ALUNO.txt");
            BufferedReader br1 = new BufferedReader(fr1);
            while((currentLine = br1.readLine()) != null){
                data = currentLine.split("@#@");
                
                
                if (data[6].equals("ATIVO")){
                    jComboBox2.addItem(data[0]+" - "+data[1]);      
                }
            }
            br1.close();
            fr1.close();
        }catch(Exception e){
        }   
        
        
    }//GEN-LAST:event_formWindowActivated

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GERADOR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GERADOR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GERADOR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GERADOR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GERADOR().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BUSCA4;
    public static javax.swing.JComboBox<String> jComboBox1;
    public static javax.swing.JComboBox<String> jComboBox2;
    public static javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    // End of variables declaration//GEN-END:variables
}
